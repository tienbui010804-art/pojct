<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "freshpizza";
    $con = mysqli_connect($servername, $username, $password, $dbname);
    
?>
